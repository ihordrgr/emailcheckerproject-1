import React from 'react';
import EmailChecker from './email_checker_app'; // путь к компоненту

function App() {
  return <EmailChecker />;
}

export default App;


